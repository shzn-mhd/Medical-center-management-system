﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace MedicalCentre
{
    public partial class PharmacistHome : Form
    {
        MySqlConnection conn = new MySqlConnection("server=localhost;user=root;database=mcuov;port=3306;password=");
        public PharmacistHome()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Login lg=new Login();
            this.Hide();
            lg.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sql = "SELECT * FROM stdreg WHERE regNum='" + txtRegNum.Text + "'";
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            conn.Open();
            using (MySqlDataReader dr = cmd.ExecuteReader())
            {
                if (dr.Read())
                {
                    stName.Text = dr["name"].ToString();
                    stFac.Text = dr["faculty"].ToString();
                    stDep.Text = dr["dept"].ToString();
                }
            }

            string ConnectionString = "server=localhost;user=root;database=mcuov;port=3306;password=";
            using (MySqlConnection dat = new MySqlConnection(ConnectionString))
            {
                //Data Set 1
                MySqlDataAdapter sqlDa = new MySqlDataAdapter("SELECT regNum,date,findings,medicine FROM mcuov.std_prescription WHERE regNum='" + txtRegNum.Text + "' ", dat);
                DataTable tbl = new DataTable();
                sqlDa.Fill(tbl);

                dataMed.DataSource = tbl;

                
            }
            conn.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            stDep.Text = "";
            stFac.Text = "";
            stName.Text = "";
            txtRegNum.Text = "";
            txtStaffId.Text = "";
            
            
        }

        private void PharmacistHome_Load(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            string sql = "SELECT * FROM stfreg WHERE stfId='" + txtStaffId.Text + "'";
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            conn.Open();
            using (MySqlDataReader dr2 = cmd.ExecuteReader())
            {
                if (dr2.Read())
                {
                    stName.Text = dr2["name"].ToString();
                    stFac.Text = dr2["faculty"].ToString();
                    stDep.Text = dr2["dept"].ToString();
                }
            }

            string ConnectionString = "server=localhost;user=root;database=mcuov;port=3306;password=";
            using (MySqlConnection dat = new MySqlConnection(ConnectionString))
            {
                //Data Set 1
                MySqlDataAdapter sqlDa = new MySqlDataAdapter("SELECT stfId,date,findings,medicine FROM mcuov.stf_prescription WHERE stfId='" + txtStaffId.Text + "' ", dat);
                DataTable tbl = new DataTable();
                sqlDa.Fill(tbl);

                dataMed.DataSource = tbl;


            }
            conn.Close();
        }
    }
}
