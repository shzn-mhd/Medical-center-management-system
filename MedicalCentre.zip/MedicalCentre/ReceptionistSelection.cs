﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedicalCentre
{
    public partial class ReceptionistSelection : Form
    {
        public ReceptionistSelection()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            StudentReg rc=new StudentReg();
            rc.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Login lg=new Login();
            lg.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            StaffReg st=new StaffReg();
            st.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MedicalCertificate md=new MedicalCertificate();
            this.Hide();
            md.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Dental dn=new Dental();
            this.Hide();
            dn.Show();
        }

        private void ReceptionistSelection_Load(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            Records rc=new Records();
            
            rc.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            VisionApp vs = new VisionApp();
            this.Hide();
            vs.Show();
        }
    }
}
