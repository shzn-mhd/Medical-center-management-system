﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace MedicalCentre
{
    public partial class StaffAll : Form
    {
        MySqlConnection conn = new MySqlConnection("server=localhost;user=root;database=mcuov;port=3306;password=");
        
        public StaffAll()
        {
            InitializeComponent();
        }

        private void StaffAll_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string connectionString = "server=localhost;user=root;database=mcuov;port=3306;password=";
            using (MySqlConnection dat = new MySqlConnection(connectionString))
            {
                MySqlDataAdapter sqlDa = new MySqlDataAdapter("SELECT * FROM mcuov.stfreg ", dat);
                DataTable tbl = new DataTable();
                sqlDa.Fill(tbl);

                dataViewStf.DataSource = tbl;
            }
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connectionString = "server=localhost;user=root;database=mcuov;port=3306;password=";  
            using (MySqlConnection dat = new MySqlConnection(connectionString))
            {
                MySqlDataAdapter sqlDa = new MySqlDataAdapter("SELECT * FROM mcuov.stfreg WHERE stfId='" + stfReg.Text + "' ", dat);
                DataTable tbl = new DataTable();
                sqlDa.Fill(tbl);

                dataViewStf.DataSource = tbl;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in dataViewStf.Rows)
            {
                MessageBox.Show("Updated");
            }
        }

        private void dataViewStf_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //conn.Open();

            //try
            //{
            //    foreach (DataGridViewRow row in dataViewStf.Rows)
            //    {
            //        string name2 = row.Cells["name"].ToString();
            //        string query = "update mcuov.stfreg set name=@name where stfId = @stfId";

            //        MySqlCommand cmd = new MySqlCommand(query, conn);

            //        cmd.Parameters.AddWithValue("@name", name2);
            //        cmd.Parameters.AddWithValue("@stfId", row.Cells["stfId"]);

            //        cmd.ExecuteNonQuery();

            //    }


            //}
            //catch (Exception exc)
            //{
            //    MessageBox.Show(exc.Message);
            //}
            //conn.Close();
        }

        private void dataViewStf_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            conn.Open();

            try
            {
                foreach (DataGridViewRow row in dataViewStf.Rows)
                {
                    string name2 = row.Cells[1].Value.ToString();
                    string age = row.Cells[3].Value.ToString();
                    string desig = row.Cells[5].Value.ToString();
                    string allergic = row.Cells[6].Value.ToString();
                    string dept=row.Cells[7].Value.ToString();
                    string faculty=row.Cells[8].Value.ToString();
                    string resAddress=row.Cells[9].Value.ToString();
                    string perAddress=row.Cells[10].Value.ToString();
                    string allergicHx=row.Cells[11].Value.ToString();
                    string pastMedHis=row.Cells[12].Value.ToString();
                    string pastSurgery=row.Cells[13].Value.ToString();
                    string vaccination=row.Cells[14].Value.ToString();

                    string query = "update mcuov.stfreg set name=@name,age=@age,designation=@designation,allergic=@allergic,dept=@dept,faculty=@faculty,resAddress=@resAddress,perAddress=@perAddress,allergicHx=@allergicHx,pastMedHis=@pastMedHis,pastSurgery=@pastSurgery,vaccination=@vaccination where stfId = @stfId";

                    MySqlCommand cmd = new MySqlCommand(query, conn);

                    //MessageBox.Show(name2);
                    //MessageBox.Show(row.Cells[0].ToString());

                    cmd.Parameters.AddWithValue("@name", name2);
                    cmd.Parameters.AddWithValue("@age", age);
                    cmd.Parameters.AddWithValue("@designation", desig);
                    cmd.Parameters.AddWithValue("@allergic", allergic);
                    cmd.Parameters.AddWithValue("@dept",dept);
                    cmd.Parameters.AddWithValue("@faculty",faculty);
                    cmd.Parameters.AddWithValue("@resAddress", resAddress);
                    cmd.Parameters.AddWithValue("@perAddress", perAddress);
                    cmd.Parameters.AddWithValue("@allergicHx", allergicHx);
                    cmd.Parameters.AddWithValue("@pastMedHis", pastMedHis);
                    cmd.Parameters.AddWithValue("@pastSurgery", pastSurgery);
                    cmd.Parameters.AddWithValue("@vaccination", vaccination);

                    cmd.Parameters.AddWithValue("@stfId", row.Cells[0].Value);

                    cmd.ExecuteNonQuery();

                    string query2 = "select * from mcuov.stfreg where stfId=@stfId";
                    MySqlCommand cmd2 = new MySqlCommand(query2, conn);

                    cmd2.Parameters.AddWithValue("@stfId", row.Cells[0].Value);
                    cmd2.ExecuteNonQuery();

                }
                
                    
                
                
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
            conn.Close();
        }
    }
}
