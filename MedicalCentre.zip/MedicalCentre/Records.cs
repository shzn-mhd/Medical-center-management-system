﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace MedicalCentre
{
    public partial class Records : Form
    {
        MySqlConnection conn = new MySqlConnection("server=localhost;user=root;database=mcuov;port=3306;password=");
        public Records()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Login lg=new Login();
            this.Hide();
            lg.Show();
        }

       

        private void button1_Click(object sender, EventArgs e)
        {
            string connectionString = "server=localhost;user=root;database=mcuov;port=3306;password=";
            using (MySqlConnection dat = new MySqlConnection(connectionString))
            {
                MySqlDataAdapter sqlDa = new MySqlDataAdapter("SELECT * FROM mcuov.dental ", dat);
                DataTable tbl = new DataTable();
                sqlDa.Fill(tbl);

                allData.DataSource = tbl;
            }

            head.Text = "Dental Appointments";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string connectionString = "server=localhost;user=root;database=mcuov;port=3306;password=";
            using (MySqlConnection dat = new MySqlConnection(connectionString))
            {
                MySqlDataAdapter sqlDa = new MySqlDataAdapter("SELECT * FROM mcuov.medical_certificate ", dat);
                DataTable tbl = new DataTable();
                sqlDa.Fill(tbl);

                allData.DataSource = tbl;
            }

            head.Text = "Medical Certificate Appointments";

        }

        private void button4_Click(object sender, EventArgs e)
        {
            string connectionString = "server=localhost;user=root;database=mcuov;port=3306;password=";
            using (MySqlConnection dat = new MySqlConnection(connectionString))
            {
                MySqlDataAdapter sqlDa = new MySqlDataAdapter("SELECT * FROM mcuov.std_prescription ", dat);
                DataTable tbl = new DataTable();
                sqlDa.Fill(tbl);

                allData.DataSource = tbl;
            }

            head.Text = "Student's Medical Prescriptions";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string connectionString = "server=localhost;user=root;database=mcuov;port=3306;password=";
            using (MySqlConnection dat = new MySqlConnection(connectionString))
            {
                MySqlDataAdapter sqlDa = new MySqlDataAdapter("SELECT * FROM mcuov.stf_prescription ", dat);
                DataTable tbl = new DataTable();
                sqlDa.Fill(tbl);

                allData.DataSource = tbl;
            }

            head.Text = "Staff's Medical Prescriptions";
        }

        private void head_Click(object sender, EventArgs e)
        {

        }

        private void Records_Load(object sender, EventArgs e)
        {

        }
    }
}
