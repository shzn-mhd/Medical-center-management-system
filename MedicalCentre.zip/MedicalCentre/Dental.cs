﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace MedicalCentre
{
    public partial class Dental : Form
    {
        MySqlConnection conn = new MySqlConnection("server=localhost;user=root;database=mcuov;port=3306;password=");
        public Dental()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ReceptionistSelection rec=new ReceptionistSelection();
            this.Hide();
            rec.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Login lg=new Login();
            this.Hide();
            lg.Show();
        }

        private void Dental_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string insertQuery = "INSERT INTO mcuov.dental(RegNum,Name,Age,Sex,Department,Faculty,Date,Issues) VALUES('" + txtReg.Text + "','" + txtName.Text + "','" + txtAge.Text + "','" + txtSex.Text + "','" + txtDep.Text + "','" + txtFac.Text + "','" + txtDate.Text + "','" + txtIssue.Text + "')";
            conn.Open();
            MySqlCommand cmd = new MySqlCommand(insertQuery, conn);

            try
            {
                if (cmd.ExecuteNonQuery() == 1)
                {
                    MessageBox.Show("Appointment Success!");
                }
                else
                {
                    MessageBox.Show("Appointment Failed");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            conn.Close();

            txtAge.Text = "";
            txtDate.Text = "";
            txtDep.Text = "";
            txtFac.Text = "";
            txtIssue.Text = "";
            txtName.Text = "";
            txtReg.Text = "";
            txtSex.Text = "";
        }
    }
}
